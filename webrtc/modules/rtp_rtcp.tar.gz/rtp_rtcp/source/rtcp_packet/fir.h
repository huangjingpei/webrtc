/*
 *  Copyright (c) 2016 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef WEBRTC_MODULES_RTP_RTCP_SOURCE_RTCP_PACKET_FIR_H_
#define WEBRTC_MODULES_RTP_RTCP_SOURCE_RTCP_PACKET_FIR_H_

#include <vector>

#include "webrtc/base/basictypes.h"
#include "webrtc/modules/rtp_rtcp/source/rtcp_packet/psfb.h"
#include "webrtc/modules/rtp_rtcp/source/rtcp_utility.h"

namespace webrtc {
namespace rtcp {
// Full intra request (FIR) (RFC 5104).
class Fir : public Psfb {
 public:
  static const uint8_t kFeedbackMessageType = 4;
  struct Request {
    Request() : ssrc(0), seq_nr(0) {}
    Request(uint32_t ssrc, uint8_t seq_nr) : ssrc(ssrc), seq_nr(seq_nr) {}
    uint32_t ssrc;
    uint8_t seq_nr;
  };

  Fir() {}
  ~Fir() override {}

  // Parse assumes header is already parsed and validated.
  bool Parse(const RTCPUtility::RtcpCommonHeader& header,
             const uint8_t* payload);  // Size of the payload is in the header.

  void WithRequestTo(uint32_t ssrc, uint8_t seq_num) {
    items_.push_back(Request(ssrc, seq_num));
  }
  const std::vector<Request>& requests() const { return items_; }

 protected:
  bool Create(uint8_t* packet,
              size_t* index,
              size_t max_length,
              RtcpPacket::PacketReadyCallback* callback) const override;

 private:
  static const size_t kFciLength = 8;
  size_t BlockLength() const override {
    return kHeaderLength + kCommonFeedbackLength + kFciLength * items_.size();
  }
  // SSRC of media source is not used in FIR packet. Shadow base functions.
  void To(uint32_t ssrc);
  uint32_t media_ssrc() const;

  std::vector<Request> items_;
};
}  // namespace rtcp
}  // namespace webrtc
#endif  // WEBRTC_MODULES_RTP_RTCP_SOURCE_RTCP_PACKET_FIR_H_
